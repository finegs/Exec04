#include<iostream>
#include<thread>
#include<chrono>

using namespace std;
using namespace std::chrono;


void run01()
{
	int i = 0;
	cout << "run01 : Init " << endl;
	while(true)
	{
		this_thread::sleep_for(milliseconds(3000));
		cout << "run01 : " << i++ << endl;
	}
	cout << "run01 : Done" <<endl;
//	return EXIT_SUCCESS;
}

int main(int argc, char* arg[])
{
	thread a(run01);
	int i = 0;
	while(1)
	{
		this_thread::sleep_for(milliseconds(10000));
		cout << "main : " << i++ << endl;
	}
	return EXIT_SUCCESS;
}
