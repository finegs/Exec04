#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>

using namespace std;
int main(int argc, char* argv[])
{
	char* msg = new char[100];
	memset(msg, '\0', 100);
	printf("MSG : "); fflush(stdout);
	scanf("%s", msg);
	printf("Your MSG : %s\n", msg);

	string s(msg);
	cout << "string :" << s << ", &string" << s.c_str()  << endl;

	return EXIT_SUCCESS;
}
