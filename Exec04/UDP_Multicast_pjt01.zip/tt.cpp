#include <iostream>
#include <string>
#include <sstream>
#include <cstdio>
#include <vector>
#include <sys/time.h>
#include <time.h>
#include <thread>
#include <mutex>
#include <unistd.h>
#include <chrono>
#include <deque>
#include <queue>
#include <condition_variable>
#include <string>

using namespace std;

//std::deque<int> q;
std::priority_queue<int> q;
std::mutex mu;
std::condition_variable cond;

void function_1() {

	int count = 10;

	while(count > 0) {

		std::unique_lock<std::mutex> locker(mu);

		//q.push_front(count);
		q.push(count);

		locker.unlock();

		cond.notify_all();

		cout << "t1 push : " << count << endl;

		this_thread::sleep_for(chrono::seconds(1));

		count--;
	}
}

void function_2() {

	int data = 0;

	while(data != 1) {

		std::unique_lock<std::mutex> locker(mu);
		cond.wait(locker, [](){ return !q.empty();}); // spurious wake
//		data = q.back();
//		q.pop_back();
		data = q.top();
		q.pop();
		locker.unlock();
		cout << "t2 got a value from t1: " << data << std::endl;

	}
}

class MyC
{
	public:
		explicit MyC(const std::string& _s) : msg(_s) {}
		MyC() {}
			
		MyC(const MyC& o) : msg(o.msg) {}
		MyC(MyC&& o)  : msg(std::move(o.msg)) {}

		MyC& operator=(const MyC& o)
		{
			if(this==&o) return *this;
			msg = o.msg;
			return *this;
		}

		MyC& operator=(MyC&& o)
		{
			if(this==&o) return *this;
			msg = std::move(o.msg);
			return *this;
		}

		friend std::ostream& operator<<(std::ostream& os, const MyC& o)
		{
			os << o.msg << std::endl;
			return os;
		}

	private:
		std::string msg;
};

int main()
{
	cout << "start" << std::endl;

	std::thread t1(function_2);
	std::thread t2(function_1);

	t1.join();
	t2.join();

	cout << "done." << std::endl;
}

